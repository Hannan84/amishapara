UPDATE `business_settings` SET `value` = '2.6' WHERE `business_settings`.`type` = 'current_version';

COMMIT;
